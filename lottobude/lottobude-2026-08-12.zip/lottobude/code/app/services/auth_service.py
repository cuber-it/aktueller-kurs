"""Anmeldung.

Trainingsanwendung: Passwoerter werden als SHA-256 abgelegt. Das ist fuer
Produktivbetrieb nicht ausreichend und hier bewusst einfach gehalten,
damit der Ablauf im Kurs nachvollziehbar bleibt.
"""
import hashlib

from sqlalchemy.orm import Session

from app.domain.models import User
from app.domain.rules import RegelVerstoss


def hashe(passwort: str) -> str:
    return hashlib.sha256(passwort.encode("utf-8")).hexdigest()


def melde_an(session: Session, username: str, passwort: str) -> User:
    """Prueft Zugangsdaten und Aktivstatus (BR-USER-001)."""
    if not username or not passwort:
        raise RegelVerstoss(
            "LOGIN_INCOMPLETE", "Benutzername und Passwort sind erforderlich."
        )

    benutzer = (
        session.query(User).filter(User.username == username.strip()).first()
    )
    if benutzer is None or benutzer.password_hash != hashe(passwort):
        # Bewusst dieselbe Meldung fuer unbekannten Benutzer und falsches
        # Passwort - erlaubt keine Rueckschluesse auf existierende Konten.
        raise RegelVerstoss(
            "LOGIN_INVALID", "Benutzername oder Passwort ist falsch."
        )

    if not benutzer.active:
        raise RegelVerstoss(
            "USER_INACTIVE", f"Der Benutzer {benutzer.username} ist gesperrt."
        )

    return benutzer
