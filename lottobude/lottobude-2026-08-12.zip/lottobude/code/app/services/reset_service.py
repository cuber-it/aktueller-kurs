"""Trainingsreset (LOTTO-501).

Der Reset laeuft ohne Neubau der Anwendung: Daten loeschen, Fixtures laden.
Die Bug-Konfiguration kommt aus der Umgebung und bleibt dadurch unberuehrt.
"""
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.domain.models import (
    CsvImport, Draw, Evaluation, FixtureState, ImportError, Outlet, Ticket, Tip, User,
)
from app.services.fixtures import lade_fixtures

# Reihenfolge beachten: abhaengige Tabellen zuerst.
LOESCHREIHENFOLGE = [
    FixtureState,
    Evaluation,
    ImportError,
    Tip,
    Ticket,
    CsvImport,
    Draw,
    Outlet,
    User,
]


def setze_zurueck(session: Session) -> dict:
    """Leert alle Tabellen und setzt die Sequenzen zurueck.

    Ohne RESTART IDENTITY zaehlen die Primaerschluessel nach jedem Reset
    weiter. Die Ausgangsdaten waeren dann nicht reproduzierbar, und
    Testfaelle, die auf konkrete IDs verweisen, wuerden danach andere
    Datensaetze treffen.
    """
    tabellen = ", ".join(modell.__tablename__ for modell in LOESCHREIHENFOLGE)
    session.execute(text(f"TRUNCATE TABLE {tabellen} RESTART IDENTITY CASCADE"))
    session.commit()

    ergebnis = lade_fixtures(session)
    return {"status": "zurueckgesetzt", **ergebnis}
