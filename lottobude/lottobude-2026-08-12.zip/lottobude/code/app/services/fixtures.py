"""Definierter Ausgangszustand laut TRAINING_CONCEPT.md.

Alle Werte sind fest verdrahtet - der Zustand muss nach jedem Reset
exakt gleich sein, sonst taugt er nicht als Testorakel.
Die Ziehungsdaten sind bewusst identisch mit den Beispielen in CSV_FORMAT.md,
damit die dortigen CSV-Beispiele unveraendert verwendbar sind.
"""
from datetime import date

from sqlalchemy.orm import Session

from app.domain.enums import TicketSource, TicketStatus
from app.domain.models import Draw, FixtureState, Outlet, Ticket, Tip, User
from app.services import auth_service, draw_service, evaluation_service, ticket_service

FIXTURE_VERSION = "3"

STANDARD_PASSWORT = "lotto123"
ADMIN_PASSWORT = "spielleitung2026"

ZIEHUNG_OFFEN = date(2026, 8, 15)
ZIEHUNG_ABGESCHLOSSEN = date(2026, 8, 8)
GEWINNZAHLEN_ABGESCHLOSSEN = [3, 7, 12, 18, 23, 31]


def lade_fixtures(session: Session) -> dict:
    """Legt Benutzer, Annahmestellen, Ziehungen und Tippscheine an."""
    passwort = auth_service.hashe(STANDARD_PASSWORT)
    spieler1 = User(username="spieler1", display_name="Spieler Eins",
                    active=True, password_hash=passwort)
    spieler2 = User(username="spieler2", display_name="Spieler Zwei",
                    active=True, password_hash=passwort)
    # Dritter Benutzer bewusst gesperrt, damit BR-USER-001 ueber die
    # Oberflaeche pruefbar ist.
    gesperrt = User(username="gesperrt", display_name="Gesperrter Spieler",
                    active=False, password_hash=passwort)
    # Spielleitung: eigenes Konto, kein Spielbetrieb.
    admin = User(username="admin", display_name="Spielleitung",
                 active=True, password_hash=auth_service.hashe(ADMIN_PASSWORT),
                 is_admin=True)
    session.add_all([spieler1, spieler2, gesperrt, admin])

    outlet_hh = Outlet(code="HH", name="Annahmestelle Hamburg", active=True)
    outlet_b = Outlet(code="B", name="Annahmestelle Berlin", active=True)
    session.add_all([outlet_hh, outlet_b])
    session.commit()

    # Abgeschlossene Ziehung: anlegen, betippen, ziehen, auswerten.
    # Bewusst ueber die echten Services, damit der Zustand konsistent ist.
    alt = draw_service.lege_ziehung_an(session, ZIEHUNG_ABGESCHLOSSEN)

    ticket_alt = ticket_service.erstelle_tippschein(session, spieler1.id, alt.id)
    ticket_service.fuege_tipp_hinzu(session, ticket_alt.id, [3, 7, 12, 18, 23, 31])
    ticket_service.fuege_tipp_hinzu(session, ticket_alt.id, [1, 2, 3, 4, 5, 6])
    ticket_service.gib_tippschein_ab(session, ticket_alt.id)

    ticket_alt2 = ticket_service.erstelle_tippschein(session, spieler2.id, alt.id)
    ticket_service.fuege_tipp_hinzu(session, ticket_alt2.id, [3, 7, 12, 40, 41, 42])
    ticket_service.gib_tippschein_ab(session, ticket_alt2.id)

    draw_service.erfasse_gewinnzahlen(session, alt.id, GEWINNZAHLEN_ABGESCHLOSSEN)
    evaluation_service.werte_ziehung_aus(session, alt.id)

    # Offene Ziehung mit bereits abgegebenen und einem offenen Tippschein.
    neu = draw_service.lege_ziehung_an(session, ZIEHUNG_OFFEN)

    ticket_neu = ticket_service.erstelle_tippschein(session, spieler1.id, neu.id)
    ticket_service.fuege_tipp_hinzu(session, ticket_neu.id, [5, 11, 19, 27, 33, 44])
    ticket_service.gib_tippschein_ab(session, ticket_neu.id)

    entwurf = ticket_service.erstelle_tippschein(session, spieler2.id, neu.id)
    ticket_service.fuege_tipp_hinzu(session, entwurf.id, [2, 8, 14, 21, 36, 49])

    # Ein Tippschein, der ueber eine Annahmestelle eingegangen ist.
    csv_ticket = Ticket(
        draw_id=neu.id,
        outlet_id=outlet_hh.id,
        external_ticket_id="HH-10001",
        source=TicketSource.CSV,
        status=TicketStatus.ABGEGEBEN,
    )
    session.add(csv_ticket)
    session.commit()
    session.add(
        Tip(ticket_id=csv_ticket.id, tip_no=1,
            n1=4, n2=11, n3=19, n4=22, n5=33, n6=41)
    )
    session.commit()

    # Marker zuletzt: erst jetzt gilt der Ausgangszustand als vollstaendig.
    session.add(FixtureState(version=FIXTURE_VERSION))
    session.commit()

    return {
        "users": 4,
        "outlets": 2,
        "draws": 2,
        "offene_ziehung": str(ZIEHUNG_OFFEN),
        "abgeschlossene_ziehung": str(ZIEHUNG_ABGESCHLOSSEN),
    }
