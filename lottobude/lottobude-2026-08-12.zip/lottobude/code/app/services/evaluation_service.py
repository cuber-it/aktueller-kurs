"""Auswertung (EPIC-4)."""
from datetime import datetime

from sqlalchemy.orm import Session

from app.config import settings
from app.domain import rules
from app.domain.enums import DrawStatus, TicketStatus
from app.domain.models import Draw, Evaluation, Ticket, Tip
from app.domain.rules import RegelVerstoss


def werte_ziehung_aus(session: Session, draw_id: int) -> dict:
    """LOTTO-401: Alle abgegebenen Tipps einer Ziehung auswerten.

    BR-DRAW-003: nur eine durchgefuehrte Ziehung darf ausgewertet werden.
    BR-DRAW-004: eine bereits ausgewertete Ziehung nicht erneut.
    BR-WIN-002: jeder Tipp wird unabhaengig ausgewertet.
    """
    draw = session.get(Draw, draw_id)
    if draw is None:
        raise RegelVerstoss("DRAW_NOT_FOUND", f"Ziehung {draw_id} existiert nicht.")
    if draw.status is DrawStatus.AUSGEWERTET and not settings.bug_doppelte_auswertung:
        raise RegelVerstoss(
            "DRAW_ALREADY_EVALUATED",
            f"Ziehung {draw.draw_date} wurde bereits ausgewertet.",
        )
    if draw.status not in (DrawStatus.DURCHGEFUEHRT, DrawStatus.AUSGEWERTET):
        raise RegelVerstoss(
            "DRAW_NOT_COMPLETED",
            f"Ziehung {draw.draw_date} ist noch nicht durchgefuehrt.",
        )

    gewinnzahlen = draw.winning_numbers
    tickets = (
        session.query(Ticket)
        .filter(
            Ticket.draw_id == draw.id,
            Ticket.status.in_([TicketStatus.ABGEGEBEN, TicketStatus.AUSGEWERTET])
            if settings.bug_doppelte_auswertung
            else Ticket.status == TicketStatus.ABGEGEBEN,
        )
        .all()
    )

    ausgewertet = 0
    gesamtgewinn = 0
    for ticket in tickets:
        for tip in ticket.tips:
            treffer = rules.ermittle_treffer(tip.numbers, gewinnzahlen)
            klasse, betrag = rules.ermittle_gewinn(treffer)
            session.add(
                Evaluation(
                    tip_id=tip.id,
                    draw_id=draw.id,
                    hit_count=treffer,
                    prize_class=klasse,
                    prize_amount=betrag,
                )
            )
            ausgewertet += 1
            gesamtgewinn += betrag
        ticket.status = TicketStatus.AUSGEWERTET

    draw.status = DrawStatus.AUSGEWERTET
    draw.evaluated_at = datetime.now()
    session.commit()

    return {
        "draw_id": draw.id,
        "draw_date": str(draw.draw_date),
        "winning_numbers": gewinnzahlen,
        "tickets_evaluated": len(tickets),
        "tips_evaluated": ausgewertet,
        "total_prize": float(gesamtgewinn),
    }


def ergebnisse_von_benutzer(session: Session, user_id: int, draw_id: int) -> list[dict]:
    """LOTTO-402: Ergebnisse der eigenen Tipps zu einer Ziehung."""
    zeilen = (
        session.query(Evaluation, Tip, Ticket)
        .join(Tip, Evaluation.tip_id == Tip.id)
        .join(Ticket, Tip.ticket_id == Ticket.id)
        .filter(Ticket.user_id == user_id, Evaluation.draw_id == draw_id)
        .order_by(Ticket.id, Tip.tip_no)
        .all()
    )
    return [
        {
            "ticket_id": ticket.id,
            "tip_no": tip.tip_no,
            "numbers": tip.numbers,
            "hit_count": ev.hit_count,
            "prize_class": ev.prize_class,
            "prize_amount": float(ev.prize_amount),
        }
        for ev, tip, ticket in zeilen
    ]
