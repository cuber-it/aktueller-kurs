"""Tippscheine und Tipps (EPIC-1)."""
from datetime import datetime

from sqlalchemy.orm import Session

from app.config import settings
from app.domain import rules
from app.domain.enums import DrawStatus, TicketSource, TicketStatus
from app.domain.models import Draw, Ticket, Tip, User
from app.domain.rules import RegelVerstoss


def hole_offene_ziehung(session: Session, draw_id: int) -> Draw:
    """BR-TICKET-002: Ziehung muss existieren und fuer Tipps offen sein."""
    draw = session.get(Draw, draw_id)
    if draw is None:
        raise RegelVerstoss("DRAW_NOT_FOUND", f"Ziehung {draw_id} existiert nicht.")
    if draw.status is not DrawStatus.GEPLANT:
        raise RegelVerstoss(
            "DRAW_CLOSED",
            f"Ziehung {draw.draw_date} nimmt keine Tipps mehr an "
            f"(Status {draw.status.value}).",
        )
    return draw


def erstelle_tippschein(session: Session, user_id: int, draw_id: int) -> Ticket:
    """LOTTO-101: Tippschein im Status ENTWURF anlegen."""
    user = session.get(User, user_id)
    if user is None:
        raise RegelVerstoss("USER_NOT_FOUND", f"Benutzer {user_id} existiert nicht.")
    if not user.active and not settings.bug_gesperrter_darf_abgeben:
        # BR-USER-001
        raise RegelVerstoss(
            "USER_INACTIVE", f"Benutzer {user.username} ist nicht aktiv."
        )

    draw = hole_offene_ziehung(session, draw_id)

    ticket = Ticket(
        draw_id=draw.id,
        user_id=user.id,
        source=TicketSource.WEB,
        status=TicketStatus.ENTWURF,
    )
    session.add(ticket)
    session.commit()
    return ticket


def fuege_tipp_hinzu(session: Session, ticket_id: int, zahlen: list) -> Tip:
    """LOTTO-101: Tipp zu einem Tippschein im Entwurf hinzufuegen."""
    ticket = session.get(Ticket, ticket_id)
    if ticket is None:
        raise RegelVerstoss("TICKET_NOT_FOUND", f"Tippschein {ticket_id} existiert nicht.")
    if ticket.status is not TicketStatus.ENTWURF and not settings.bug_abgegebener_schein_aenderbar:
        # BR-TICKET-003
        raise RegelVerstoss(
            "TICKET_NOT_EDITABLE",
            f"Tippschein {ticket_id} ist bereits abgegeben und unveraenderlich.",
        )

    geprueft = rules.pruefe_tippzahlen(zahlen)

    # Anzahl und laufende Nummer aus der Datenbank bestimmen - eine im
    # Speicher gehaltene Collection kann nach einem Commit veraltet sein.
    vorhandene = session.query(Tip).filter(Tip.ticket_id == ticket.id).count()
    rules.pruefe_tippanzahl(vorhandene + 1)

    tip = Tip(
        ticket_id=ticket.id,
        tip_no=vorhandene + 1,
        n1=geprueft[0], n2=geprueft[1], n3=geprueft[2],
        n4=geprueft[3], n5=geprueft[4], n6=geprueft[5],
    )
    session.add(tip)
    session.commit()
    return tip


def gib_tippschein_ab(session: Session, ticket_id: int) -> Ticket:
    """LOTTO-101: Tippschein abgeben - danach unveraenderlich (BR-TICKET-003)."""
    ticket = session.get(Ticket, ticket_id)
    if ticket is None:
        raise RegelVerstoss("TICKET_NOT_FOUND", f"Tippschein {ticket_id} existiert nicht.")
    if ticket.status is not TicketStatus.ENTWURF:
        raise RegelVerstoss(
            "TICKET_NOT_EDITABLE",
            f"Tippschein {ticket_id} wurde bereits abgegeben.",
        )

    anzahl = session.query(Tip).filter(Tip.ticket_id == ticket.id).count()
    rules.pruefe_tippanzahl(anzahl)
    hole_offene_ziehung(session, ticket.draw_id)

    ticket.status = TicketStatus.ABGEGEBEN
    ticket.submitted_at = datetime.now()
    session.commit()
    return ticket


def tippscheine_von_benutzer(session: Session, user_id: int) -> list[Ticket]:
    """LOTTO-102 in Verbindung mit BR-USER-002."""
    return (
        session.query(Ticket)
        .filter(Ticket.user_id == user_id)
        .order_by(Ticket.id.desc())
        .all()
    )
