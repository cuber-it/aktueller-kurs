"""CSV-Import fuer Annahmestellen (LOTTO-201).

Format und Fehlercodes exakt nach CSV_FORMAT.md.
Verhalten nach LOTTO-201: gueltige Tipps werden gespeichert, ungueltige
Daten abgewiesen - also Teilimport, kein Verwerfen der ganzen Datei.

Bewusst nicht implementiert, weil in den Stories nicht gefordert:
Erkennung wiederholter Uploads, globale Eindeutigkeit der ticket_id,
Sonderbehandlung von Leerzeichen, Leerzeilen, BOM oder Dateigroesse.
"""
import csv
import io
from datetime import date, datetime

from sqlalchemy.orm import Session

from app.config import settings
from app.domain import rules
from app.domain.enums import DrawStatus, ImportStatus, TicketSource, TicketStatus
from app.domain.models import CsvImport, Draw, ImportError, Outlet, Ticket, Tip
from app.domain.rules import RegelVerstoss

KOPFZEILE = ["ticket_id", "draw_date", "tip_no", "n1", "n2", "n3", "n4", "n5", "n6"]
SPALTENZAHL = len(KOPFZEILE)


class Zeilenfehler(Exception):
    def __init__(self, error_code: str, message: str):
        super().__init__(message)
        self.error_code = error_code
        self.message = message


def _pruefe_ziehung(session: Session, wert: str) -> Draw:
    """draw_date muss auf eine existierende, offene Ziehung zeigen."""
    try:
        gewuenscht = date.fromisoformat(wert)
    except (TypeError, ValueError):
        raise Zeilenfehler("DRAW_NOT_FOUND", f"'{wert}' ist kein Datum im Format YYYY-MM-DD.")

    draw = session.query(Draw).filter(Draw.draw_date == gewuenscht).first()
    if draw is None:
        raise Zeilenfehler("DRAW_NOT_FOUND", f"Zu {wert} existiert keine Ziehung.")
    if draw.status is not DrawStatus.GEPLANT:
        raise Zeilenfehler("DRAW_CLOSED", f"Die Ziehung {wert} nimmt keine Tipps mehr an.")
    return draw


def _pruefe_zeile(session: Session, zeile: list) -> dict:
    """Prueft eine Datenzeile und liefert die geprueften Werte."""
    if len(zeile) != SPALTENZAHL:
        raise Zeilenfehler(
            "CSV_COLUMN_COUNT_INVALID",
            f"Erwartet werden {SPALTENZAHL} Spalten, gefunden {len(zeile)}.",
        )

    ticket_id = zeile[0]
    draw = _pruefe_ziehung(session, zeile[1])

    try:
        tip_no = rules.pruefe_tipp_nummer(zeile[2])
        zahlen = rules.pruefe_tippzahlen(
            zeile[3:9], duplikate_pruefen=not settings.bug_csv_duplikate_erlaubt
        )
    except RegelVerstoss as verstoss:
        raise Zeilenfehler(verstoss.error_code, verstoss.message)

    return {"ticket_id": ticket_id, "draw": draw, "tip_no": tip_no, "zahlen": zahlen}


def importiere(session: Session, outlet_id: int, dateiname: str, inhalt: bytes) -> CsvImport:
    """Liest eine CSV-Datei ein und legt Tippscheine an.

    BR-OUTLET-001: nur aktive Annahmestellen duerfen importieren.
    """
    outlet = session.get(Outlet, outlet_id)
    if outlet is None:
        raise RegelVerstoss("OUTLET_NOT_FOUND", f"Annahmestelle {outlet_id} existiert nicht.")
    if not outlet.active:
        raise RegelVerstoss("OUTLET_INACTIVE", f"Annahmestelle {outlet.code} ist nicht aktiv.")

    # Statusfolge laut DOMAIN.md vollstaendig durchlaufen:
    # HOCHGELADEN -> VALIDIERUNG -> IMPORTIERT bzw. FEHLER
    lauf = CsvImport(
        outlet_id=outlet.id, filename=dateiname, status=ImportStatus.HOCHGELADEN
    )
    session.add(lauf)
    session.commit()

    lauf.status = ImportStatus.VALIDIERUNG
    session.commit()

    text = inhalt.decode("utf-8", errors="replace")
    leser = csv.reader(io.StringIO(text), delimiter=";")

    gelesen = 0
    importiert = 0
    abgewiesen = 0
    scheine: dict[str, Ticket] = {}
    belegte_nummern: dict[str, set] = {}

    for nummer, zeile in enumerate(leser, start=1):
        if nummer == 1:
            # Header ist Pflicht (CSV_FORMAT.md).
            felder = [feld.strip() for feld in zeile]
            kopf_falsch = (
                len(felder) != SPALTENZAHL
                if settings.bug_header_nur_spaltenzahl
                else felder != KOPFZEILE
            )
            if kopf_falsch:
                lauf.status = ImportStatus.FEHLER
                session.add(
                    ImportError(
                        import_id=lauf.id, line_number=1,
                        error_code="CSV_HEADER_INVALID",
                        message="Die Kopfzeile entspricht nicht dem vereinbarten Format.",
                        raw_data=";".join(zeile),
                    )
                )
                lauf.total_records = 0
                lauf.completed_at = datetime.now()
                session.commit()
                return lauf
            continue

        gelesen += 1
        try:
            geprueft = _pruefe_zeile(session, zeile)

            schluessel = geprueft["ticket_id"]
            if schluessel in belegte_nummern and geprueft["tip_no"] in belegte_nummern[schluessel]:
                raise Zeilenfehler(
                    "TIP_NUMBER_INVALID",
                    f"Die Tippnummer {geprueft['tip_no']} kommt im Tippschein "
                    f"{schluessel} mehrfach vor.",
                )

            schein = scheine.get(schluessel)
            if schein is None:
                schein = Ticket(
                    draw_id=geprueft["draw"].id,
                    outlet_id=outlet.id,
                    external_ticket_id=schluessel,
                    source=TicketSource.CSV,
                    status=TicketStatus.ABGEGEBEN,
                    submitted_at=datetime.now(),
                )
                session.add(schein)
                session.commit()
                scheine[schluessel] = schein
                belegte_nummern[schluessel] = set()

            bisher = len(belegte_nummern[schluessel])
            try:
                rules.pruefe_tippanzahl(bisher + 1)
            except RegelVerstoss as verstoss:
                raise Zeilenfehler(verstoss.error_code, verstoss.message)

            zahlen = geprueft["zahlen"]
            session.add(
                Tip(
                    ticket_id=schein.id, tip_no=geprueft["tip_no"],
                    n1=zahlen[0], n2=zahlen[1], n3=zahlen[2],
                    n4=zahlen[3], n5=zahlen[4], n6=zahlen[5],
                )
            )
            belegte_nummern[schluessel].add(geprueft["tip_no"])
            importiert += 1
            session.commit()

        except Zeilenfehler as fehler:
            abgewiesen += 1
            session.add(
                ImportError(
                    import_id=lauf.id, line_number=nummer,
                    error_code=fehler.error_code, message=fehler.message,
                    raw_data=";".join(zeile),
                )
            )
            session.commit()

    kopfzeile_gesehen = gelesen > 0 or _hat_kopfzeile(text)
    if not kopfzeile_gesehen and not settings.bug_leere_datei_erfolg:
        # Header ist Pflicht (CSV_FORMAT.md) - eine Datei ohne Kopfzeile
        # ist kein gueltiger Import.
        session.add(
            ImportError(
                import_id=lauf.id, line_number=1,
                error_code="CSV_HEADER_INVALID",
                message="Die Datei enthaelt keine Kopfzeile.",
                raw_data="",
            )
        )
        lauf.status = ImportStatus.FEHLER
        lauf.total_records = 0
        lauf.completed_at = datetime.now()
        session.commit()
        return lauf

    lauf.total_records = gelesen
    # BUG-013: meldet die Zahl der Tippscheine statt der Tipps.
    lauf.imported_records = len(scheine) if settings.bug_importzaehler_falsch else importiert
    lauf.rejected_records = abgewiesen
    lauf.status = ImportStatus.IMPORTIERT
    lauf.completed_at = datetime.now()
    session.commit()
    return lauf


def _hat_kopfzeile(text: str) -> bool:
    return bool(text.strip())


def historie(session: Session) -> list[CsvImport]:
    """LOTTO-203: fruehere Importe."""
    return session.query(CsvImport).order_by(CsvImport.id.desc()).all()
