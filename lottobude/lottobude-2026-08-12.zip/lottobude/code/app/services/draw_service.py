"""Ziehungen (EPIC-3)."""
from datetime import date, datetime

from sqlalchemy.orm import Session

from app.domain import rules
from app.domain.enums import DrawStatus
from app.domain.models import Draw
from app.domain.rules import RegelVerstoss


def lege_ziehung_an(session: Session, draw_date: date) -> Draw:
    """LOTTO-301: Neue Ziehung im Status GEPLANT."""
    vorhanden = session.query(Draw).filter(Draw.draw_date == draw_date).first()
    if vorhanden is not None:
        raise RegelVerstoss(
            "DRAW_ALREADY_EXISTS",
            f"Fuer den {draw_date} existiert bereits eine Ziehung.",
        )
    draw = Draw(draw_date=draw_date, status=DrawStatus.GEPLANT)
    session.add(draw)
    session.commit()
    return draw


def erfasse_gewinnzahlen(session: Session, draw_id: int, zahlen: list) -> Draw:
    """LOTTO-302: Gewinnzahlen erfassen, Ziehung gilt danach als durchgefuehrt.

    BR-DRAW-002: GEPLANT -> DURCHGEFUEHRT
    """
    draw = session.get(Draw, draw_id)
    if draw is None:
        raise RegelVerstoss("DRAW_NOT_FOUND", f"Ziehung {draw_id} existiert nicht.")
    if draw.status is not DrawStatus.GEPLANT:
        raise RegelVerstoss(
            "DRAW_INVALID_STATE",
            f"Ziehung {draw.draw_date} ist bereits durchgefuehrt "
            f"(Status {draw.status.value}).",
        )

    geprueft = rules.pruefe_gewinnzahlen(zahlen)
    draw.w1, draw.w2, draw.w3, draw.w4, draw.w5, draw.w6 = geprueft
    draw.status = DrawStatus.DURCHGEFUEHRT
    draw.completed_at = datetime.now()
    session.commit()
    return draw


def liste_ziehungen(session: Session) -> list[Draw]:
    return session.query(Draw).order_by(Draw.draw_date.desc()).all()


def offene_ziehungen(session: Session) -> list[Draw]:
    return (
        session.query(Draw)
        .filter(Draw.status == DrawStatus.GEPLANT)
        .order_by(Draw.draw_date)
        .all()
    )
