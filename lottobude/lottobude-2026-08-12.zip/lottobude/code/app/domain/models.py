"""Domaenenmodell laut DOMAIN.md.

Tippzahlen und Gewinnzahlen liegen als Einzelspalten n1..n6 bzw. w1..w6 vor.
Das spiegelt das CSV-Format und bleibt fuer Datenbanktests im Kurs gut lesbar.
"""
from datetime import date, datetime

from sqlalchemy import (
    Boolean, Date, DateTime, Enum, ForeignKey, Integer, Numeric, String, Text, func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.domain.enums import DrawStatus, ImportStatus, TicketSource, TicketStatus
from app.persistence.database import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(50), unique=True)
    display_name: Mapped[str] = mapped_column(String(100))
    password_hash: Mapped[str] = mapped_column(String(128), default="")
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    tickets: Mapped[list["Ticket"]] = relationship(back_populates="user")


class Outlet(Base):
    __tablename__ = "outlets"

    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    name: Mapped[str] = mapped_column(String(100))
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    imports: Mapped[list["CsvImport"]] = relationship(back_populates="outlet")
    tickets: Mapped[list["Ticket"]] = relationship(back_populates="outlet")


class Draw(Base):
    __tablename__ = "draws"

    id: Mapped[int] = mapped_column(primary_key=True)
    draw_date: Mapped[date] = mapped_column(Date, unique=True)
    status: Mapped[DrawStatus] = mapped_column(
        Enum(DrawStatus, name="draw_status"), default=DrawStatus.GEPLANT
    )
    w1: Mapped[int | None] = mapped_column(Integer, nullable=True)
    w2: Mapped[int | None] = mapped_column(Integer, nullable=True)
    w3: Mapped[int | None] = mapped_column(Integer, nullable=True)
    w4: Mapped[int | None] = mapped_column(Integer, nullable=True)
    w5: Mapped[int | None] = mapped_column(Integer, nullable=True)
    w6: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    evaluated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    tickets: Mapped[list["Ticket"]] = relationship(back_populates="draw")

    @property
    def winning_numbers(self) -> list[int]:
        werte = [self.w1, self.w2, self.w3, self.w4, self.w5, self.w6]
        return [w for w in werte if w is not None]


class Ticket(Base):
    __tablename__ = "tickets"

    id: Mapped[int] = mapped_column(primary_key=True)
    draw_id: Mapped[int] = mapped_column(ForeignKey("draws.id"))
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    outlet_id: Mapped[int | None] = mapped_column(ForeignKey("outlets.id"), nullable=True)
    external_ticket_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    source: Mapped[TicketSource] = mapped_column(Enum(TicketSource, name="ticket_source"))
    status: Mapped[TicketStatus] = mapped_column(
        Enum(TicketStatus, name="ticket_status"), default=TicketStatus.ENTWURF
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    draw: Mapped["Draw"] = relationship(back_populates="tickets")
    user: Mapped["User | None"] = relationship(back_populates="tickets")
    outlet: Mapped["Outlet | None"] = relationship(back_populates="tickets")
    tips: Mapped[list["Tip"]] = relationship(
        back_populates="ticket", cascade="all, delete-orphan"
    )


class Tip(Base):
    __tablename__ = "tips"

    id: Mapped[int] = mapped_column(primary_key=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("tickets.id"))
    tip_no: Mapped[int] = mapped_column(Integer)
    n1: Mapped[int] = mapped_column(Integer)
    n2: Mapped[int] = mapped_column(Integer)
    n3: Mapped[int] = mapped_column(Integer)
    n4: Mapped[int] = mapped_column(Integer)
    n5: Mapped[int] = mapped_column(Integer)
    n6: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    ticket: Mapped["Ticket"] = relationship(back_populates="tips")
    evaluation: Mapped["Evaluation | None"] = relationship(back_populates="tip")

    @property
    def numbers(self) -> list[int]:
        return [self.n1, self.n2, self.n3, self.n4, self.n5, self.n6]


class CsvImport(Base):
    __tablename__ = "csv_imports"

    id: Mapped[int] = mapped_column(primary_key=True)
    outlet_id: Mapped[int] = mapped_column(ForeignKey("outlets.id"))
    filename: Mapped[str] = mapped_column(String(255))
    status: Mapped[ImportStatus] = mapped_column(
        Enum(ImportStatus, name="import_status"), default=ImportStatus.HOCHGELADEN
    )
    total_records: Mapped[int] = mapped_column(Integer, default=0)
    imported_records: Mapped[int] = mapped_column(Integer, default=0)
    rejected_records: Mapped[int] = mapped_column(Integer, default=0)
    started_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    outlet: Mapped["Outlet"] = relationship(back_populates="imports")
    errors: Mapped[list["ImportError"]] = relationship(
        back_populates="csv_import", cascade="all, delete-orphan"
    )


class ImportError(Base):
    __tablename__ = "import_errors"

    id: Mapped[int] = mapped_column(primary_key=True)
    import_id: Mapped[int] = mapped_column(ForeignKey("csv_imports.id"))
    line_number: Mapped[int] = mapped_column(Integer)
    error_code: Mapped[str] = mapped_column(String(50))
    message: Mapped[str] = mapped_column(Text)
    raw_data: Mapped[str | None] = mapped_column(Text, nullable=True)

    csv_import: Mapped["CsvImport"] = relationship(back_populates="errors")


class Evaluation(Base):
    __tablename__ = "evaluations"

    id: Mapped[int] = mapped_column(primary_key=True)
    tip_id: Mapped[int] = mapped_column(ForeignKey("tips.id"))
    draw_id: Mapped[int] = mapped_column(ForeignKey("draws.id"))
    hit_count: Mapped[int] = mapped_column(Integer)
    prize_class: Mapped[int | None] = mapped_column(Integer, nullable=True)
    prize_amount: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    evaluated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    tip: Mapped["Tip"] = relationship(back_populates="evaluation")


class FixtureState(Base):
    """Marker fuer vollstaendig geladene Fixtures.

    Wird erst geschrieben, wenn lade_fixtures() komplett durchgelaufen ist.
    Ein Abbruch mittendrin hinterlaesst damit keinen Zustand, der beim
    naechsten Start faelschlich als "schon geladen" gilt.
    """

    __tablename__ = "fixture_state"

    id: Mapped[int] = mapped_column(primary_key=True)
    version: Mapped[str] = mapped_column(String(20))
    loaded_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
