"""Fachliche Regeln laut BUSINESS_RULES.md.

Diese Modul ist die einzige Stelle, an der die Tippregeln implementiert sind.
GUI, REST-API und CSV-Import rufen dieselben Funktionen auf (BR-CONS-001).

prize_class entspricht der Trefferzahl eines Gewinns (3..6) und ist None,
wenn kein Gewinn vorliegt. Damit wird ueber die Tabelle in BUSINESS_RULES.md
hinaus nichts erfunden.
"""
from decimal import Decimal

from app.config import settings

ZAHLEN_PRO_TIPP = 6
ZAHL_MIN = 1
ZAHL_MAX = 49
TIPPS_PRO_SCHEIN_MIN = 1
TIPPS_PRO_SCHEIN_MAX = 10

GEWINNTABELLE: dict[int, Decimal] = {
    6: Decimal("1000000"),
    5: Decimal("10000"),
    4: Decimal("100"),
    3: Decimal("10"),
}


class RegelVerstoss(Exception):
    """Fachlicher Regelverstoss mit maschinenlesbarem Fehlercode."""

    def __init__(self, error_code: str, message: str):
        super().__init__(message)
        self.error_code = error_code
        self.message = message


def pruefe_tippzahlen(
    zahlen: list, duplikate_pruefen: bool = True, bereich_pruefen: bool = True
) -> list[int]:
    """Prueft BR-TIP-001 bis BR-TIP-003 und liefert die geprueften Zahlen zurueck.

    Die Reihenfolge ist fachlich bedeutungslos (BR-TIP-004), wird hier aber
    unveraendert durchgereicht, damit die Eingabe nachvollziehbar bleibt.
    """
    if len(zahlen) != ZAHLEN_PRO_TIPP:
        raise RegelVerstoss(
            "TIP_NUMBER_COUNT_INVALID",
            f"Ein Tipp muss genau {ZAHLEN_PRO_TIPP} Zahlen enthalten, "
            f"erhalten: {len(zahlen)}.",
        )

    geprueft: list[int] = []
    for wert in zahlen:
        if isinstance(wert, bool) or not isinstance(wert, int):
            try:
                roh = str(wert).strip()
                if settings.bug_zahl_abschneiden:
                    # Fuehrende Ziffern werden uebernommen, der Rest verworfen.
                    ziffern = ""
                    for zeichen in roh:
                        if not zeichen.isdigit():
                            break
                        ziffern += zeichen
                    if ziffern:
                        roh = ziffern
                wert = int(roh)
            except (TypeError, ValueError):
                raise RegelVerstoss(
                    "LOTTO_NUMBER_NOT_INTEGER",
                    f"'{wert}' ist keine ganze Zahl.",
                )
        geprueft.append(wert)

    for wert in geprueft if bereich_pruefen else []:
        if wert < ZAHL_MIN or wert > ZAHL_MAX:
            raise RegelVerstoss(
                "LOTTO_NUMBER_OUT_OF_RANGE",
                f"Die Zahl {wert} liegt ausserhalb von {ZAHL_MIN}..{ZAHL_MAX}.",
            )

    if duplikate_pruefen and len(set(geprueft)) != len(geprueft):
        raise RegelVerstoss(
            "LOTTO_NUMBER_DUPLICATE",
            "Innerhalb eines Tipps darf jede Zahl nur einmal vorkommen.",
        )

    return geprueft


def pruefe_tipp_nummer(tip_no) -> int:
    """Laufende Nummer des Tipps innerhalb eines Tippscheins (CSV_FORMAT.md)."""
    try:
        nummer = int(str(tip_no).strip())
    except (TypeError, ValueError):
        raise RegelVerstoss(
            "TIP_NUMBER_INVALID", f"'{tip_no}' ist keine gueltige Tippnummer."
        )
    if nummer < TIPPS_PRO_SCHEIN_MIN or nummer > TIPPS_PRO_SCHEIN_MAX:
        raise RegelVerstoss(
            "TIP_NUMBER_INVALID",
            f"Die Tippnummer {nummer} liegt ausserhalb von "
            f"{TIPPS_PRO_SCHEIN_MIN}..{TIPPS_PRO_SCHEIN_MAX}.",
        )
    return nummer


def pruefe_tippanzahl(anzahl: int) -> None:
    """BR-TICKET-001: mindestens 1, hoechstens 10 Tipps je Tippschein."""
    if anzahl < TIPPS_PRO_SCHEIN_MIN and not settings.bug_leerer_schein_abgebbar:
        raise RegelVerstoss(
            "TICKET_NO_TIPS",
            f"Ein Tippschein muss mindestens {TIPPS_PRO_SCHEIN_MIN} Tipp enthalten.",
        )
    obergrenze = TIPPS_PRO_SCHEIN_MAX
    if settings.bug_elf_tipps_erlaubt:
        obergrenze = TIPPS_PRO_SCHEIN_MAX + 1
    if anzahl > obergrenze:
        raise RegelVerstoss(
            "TICKET_TOO_MANY_TIPS",
            f"Ein Tippschein darf hoechstens {TIPPS_PRO_SCHEIN_MAX} Tipps enthalten, "
            f"erhalten: {anzahl}.",
        )


def pruefe_gewinnzahlen(zahlen: list) -> list[int]:
    """BR-DRAW-001: sechs unterschiedliche Zahlen aus 1..49."""
    return pruefe_tippzahlen(
        zahlen, bereich_pruefen=not settings.bug_gewinnzahl_ohne_bereich
    )


def ermittle_treffer(tippzahlen: list[int], gewinnzahlen: list[int]) -> int:
    """BR-WIN-001: Anzahl der Tippzahlen, die in den Gewinnzahlen enthalten sind."""
    return len(set(tippzahlen) & set(gewinnzahlen))


def ermittle_gewinn(treffer: int) -> tuple[int | None, Decimal]:
    """BR-WIN-001/002: Gewinnklasse und Betrag zu einer Trefferzahl."""
    if settings.bug_gewinn_vier_treffer and treffer == 4:
        return 4, Decimal("10")
    betrag = GEWINNTABELLE.get(treffer)
    if betrag is None:
        return None, Decimal("0")
    return treffer, betrag
