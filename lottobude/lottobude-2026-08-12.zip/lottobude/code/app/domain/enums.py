"""Zustaende laut DOMAIN.md."""
import enum


class DrawStatus(str, enum.Enum):
    GEPLANT = "GEPLANT"
    DURCHGEFUEHRT = "DURCHGEFUEHRT"
    AUSGEWERTET = "AUSGEWERTET"


class TicketStatus(str, enum.Enum):
    ENTWURF = "ENTWURF"
    ABGEGEBEN = "ABGEGEBEN"
    AUSGEWERTET = "AUSGEWERTET"


class TicketSource(str, enum.Enum):
    WEB = "WEB"
    CSV = "CSV"


class ImportStatus(str, enum.Enum):
    HOCHGELADEN = "HOCHGELADEN"
    VALIDIERUNG = "VALIDIERUNG"
    IMPORTIERT = "IMPORTIERT"
    FEHLER = "FEHLER"
