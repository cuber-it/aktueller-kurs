"""Ein- und Ausgabeschemata der REST-API."""
from datetime import date
from pydantic import BaseModel, Field


class TippAnlegen(BaseModel):
    numbers: list = Field(description="Sechs Lottozahlen aus 1..49")


class TippscheinAnlegen(BaseModel):
    user_id: int
    draw_id: int


class GewinnzahlenErfassen(BaseModel):
    numbers: list = Field(description="Sechs Gewinnzahlen aus 1..49")


class ZiehungAnlegen(BaseModel):
    draw_date: date


class BenutzerAus(BaseModel):
    id: int
    username: str
    display_name: str
    active: bool


class ZiehungAus(BaseModel):
    id: int
    draw_date: date
    status: str
    winning_numbers: list


class TippAus(BaseModel):
    id: int
    tip_no: int
    numbers: list


class TippscheinAus(BaseModel):
    id: int
    draw_id: int
    user_id: int | None
    outlet_id: int | None
    external_ticket_id: str | None
    source: str
    status: str
    tips: list[TippAus]


class FehlerAus(BaseModel):
    error_code: str
    message: str
