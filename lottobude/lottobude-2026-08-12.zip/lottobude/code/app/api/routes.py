"""REST-Endpunkte (ARCHITECTURE.md).

Die Endpunkte rufen dieselben Services wie die Weboberflaeche auf,
damit GUI und API fachlich nicht auseinanderlaufen (BR-CONS-001).
"""
from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.api import schemas
from app.config import settings
from app.domain.models import CsvImport, Draw, Outlet, Ticket, Tip, User
from app.persistence.database import get_session
from app.services import (
    csv_import_service, draw_service, evaluation_service, reset_service,
    ticket_service,
)

router = APIRouter(prefix="/api")


def _ticket_aus(ticket: Ticket) -> schemas.TippscheinAus:
    return schemas.TippscheinAus(
        id=ticket.id,
        draw_id=ticket.draw_id,
        user_id=ticket.user_id,
        outlet_id=ticket.outlet_id,
        external_ticket_id=ticket.external_ticket_id,
        source=ticket.source.value,
        status=ticket.status.value,
        tips=[
            schemas.TippAus(id=t.id, tip_no=t.tip_no, numbers=t.numbers)
            for t in sorted(ticket.tips, key=lambda t: t.tip_no)
        ],
    )


def _admin_pflicht(x_admin_token: str) -> None:
    """Berechtigungspruefung der Spielleitungs-Endpunkte.

    Ist BUG-001 aktiv, entfaellt die Pruefung - die Endpunkte sind dann
    ohne Anmeldung erreichbar, waehrend die Oberflaeche sie schuetzt.
    """
    if settings.bug_api_admin_offen:
        return
    if x_admin_token != settings.admin_token:
        raise HTTPException(status_code=403, detail="Kein Zugriff.")


@router.get("/users", response_model=list[schemas.BenutzerAus], tags=["users"])
def liste_benutzer(session: Session = Depends(get_session)):
    return session.query(User).order_by(User.id).all()


@router.get("/outlets", tags=["outlets"])
def liste_annahmestellen(session: Session = Depends(get_session)):
    return [
        {"id": o.id, "code": o.code, "name": o.name, "active": o.active}
        for o in session.query(Outlet).order_by(Outlet.id).all()
    ]


@router.get("/draws", response_model=list[schemas.ZiehungAus], tags=["draws"])
def liste_ziehungen(session: Session = Depends(get_session)):
    return [
        schemas.ZiehungAus(
            id=d.id, draw_date=d.draw_date, status=d.status.value,
            winning_numbers=d.winning_numbers,
        )
        for d in draw_service.liste_ziehungen(session)
    ]


@router.post("/draws", response_model=schemas.ZiehungAus, tags=["draws"])
def ziehung_anlegen(
    daten: schemas.ZiehungAnlegen,
    x_admin_token: str = Header(default=""),
    session: Session = Depends(get_session),
):
    _admin_pflicht(x_admin_token)
    draw = draw_service.lege_ziehung_an(session, daten.draw_date)
    return schemas.ZiehungAus(
        id=draw.id, draw_date=draw.draw_date, status=draw.status.value,
        winning_numbers=draw.winning_numbers,
    )


@router.post("/draws/{draw_id}/numbers", response_model=schemas.ZiehungAus, tags=["draws"])
def gewinnzahlen_erfassen(
    draw_id: int,
    daten: schemas.GewinnzahlenErfassen,
    x_admin_token: str = Header(default=""),
    session: Session = Depends(get_session),
):
    _admin_pflicht(x_admin_token)
    draw = draw_service.erfasse_gewinnzahlen(session, draw_id, daten.numbers)
    return schemas.ZiehungAus(
        id=draw.id, draw_date=draw.draw_date, status=draw.status.value,
        winning_numbers=draw.winning_numbers,
    )


@router.post("/draws/{draw_id}/evaluate", tags=["draws"])
def ziehung_auswerten(
    draw_id: int,
    x_admin_token: str = Header(default=""),
    session: Session = Depends(get_session),
):
    _admin_pflicht(x_admin_token)
    return evaluation_service.werte_ziehung_aus(session, draw_id)


def _fremdzugriff_pflicht(x_admin_token: str) -> None:
    """Schutz der lesenden Tipp-Endpunkte (BR-USER-002).

    Ist BUG-002 aktiv, entfaellt die Pruefung - fremde Tippscheine sind
    dann ueber die API einsehbar, waehrend die Oberflaeche nur die
    eigenen zeigt.
    """
    if settings.bug_fremde_tipps_lesbar:
        return
    if x_admin_token != settings.admin_token:
        raise HTTPException(status_code=403, detail="Kein Zugriff.")


@router.get("/tickets", response_model=list[schemas.TippscheinAus], tags=["tickets"])
def liste_tippscheine(
    user_id: int | None = None,
    draw_id: int | None = None,
    x_admin_token: str = Header(default=""),
    session: Session = Depends(get_session),
):
    """Tippscheine auflisten, optional nach Benutzer oder Ziehung gefiltert."""
    _fremdzugriff_pflicht(x_admin_token)
    abfrage = session.query(Ticket)
    if user_id is not None:
        abfrage = abfrage.filter(Ticket.user_id == user_id)
    if draw_id is not None:
        abfrage = abfrage.filter(Ticket.draw_id == draw_id)
    return [_ticket_aus(t) for t in abfrage.order_by(Ticket.id).all()]


@router.get("/tips", tags=["tips"])
def liste_tipps(
    ticket_id: int | None = None,
    draw_id: int | None = None,
    x_admin_token: str = Header(default=""),
    session: Session = Depends(get_session),
):
    """Tipps auflisten, optional nach Tippschein oder Ziehung gefiltert."""
    _fremdzugriff_pflicht(x_admin_token)
    abfrage = session.query(Tip)
    if ticket_id is not None:
        abfrage = abfrage.filter(Tip.ticket_id == ticket_id)
    if draw_id is not None:
        abfrage = abfrage.join(Ticket, Tip.ticket_id == Ticket.id).filter(
            Ticket.draw_id == draw_id
        )
    return [
        {"id": t.id, "ticket_id": t.ticket_id, "tip_no": t.tip_no, "numbers": t.numbers}
        for t in abfrage.order_by(Tip.ticket_id, Tip.tip_no).all()
    ]


@router.get("/tips/{tip_id}", tags=["tips"])
def tipp_lesen(tip_id: int, session: Session = Depends(get_session)):
    tip = session.get(Tip, tip_id)
    if tip is None:
        raise HTTPException(status_code=404, detail="Tipp existiert nicht.")
    return {"id": tip.id, "ticket_id": tip.ticket_id, "tip_no": tip.tip_no,
            "numbers": tip.numbers}


@router.post("/tickets", response_model=schemas.TippscheinAus, tags=["tickets"])
def tippschein_anlegen(
    daten: schemas.TippscheinAnlegen, session: Session = Depends(get_session)
):
    ticket = ticket_service.erstelle_tippschein(session, daten.user_id, daten.draw_id)
    return _ticket_aus(ticket)


@router.get("/tickets/{ticket_id}", response_model=schemas.TippscheinAus, tags=["tickets"])
def tippschein_lesen(
    ticket_id: int,
    x_admin_token: str = Header(default=""),
    session: Session = Depends(get_session),
):
    _fremdzugriff_pflicht(x_admin_token)
    ticket = session.get(Ticket, ticket_id)
    if ticket is None:
        raise HTTPException(status_code=404, detail="Tippschein existiert nicht.")
    return _ticket_aus(ticket)


@router.post("/tickets/{ticket_id}/tips", response_model=schemas.TippAus, tags=["tips"])
def tipp_hinzufuegen(
    ticket_id: int, daten: schemas.TippAnlegen, session: Session = Depends(get_session)
):
    tip = ticket_service.fuege_tipp_hinzu(session, ticket_id, daten.numbers)
    return schemas.TippAus(id=tip.id, tip_no=tip.tip_no, numbers=tip.numbers)


@router.post("/tickets/{ticket_id}/submit", response_model=schemas.TippscheinAus, tags=["tickets"])
def tippschein_abgeben(ticket_id: int, session: Session = Depends(get_session)):
    ticket = ticket_service.gib_tippschein_ab(session, ticket_id)
    return _ticket_aus(ticket)


@router.get("/users/{user_id}/tickets", response_model=list[schemas.TippscheinAus], tags=["tickets"])
def tippscheine_des_benutzers(user_id: int, session: Session = Depends(get_session)):
    return [
        _ticket_aus(t) for t in ticket_service.tippscheine_von_benutzer(session, user_id)
    ]


@router.get("/results", tags=["results"])
def ergebnisse(user_id: int, draw_id: int, session: Session = Depends(get_session)):
    return evaluation_service.ergebnisse_von_benutzer(session, user_id, draw_id)


@router.post("/admin/reset", tags=["admin"])
def trainingsdaten_zuruecksetzen(
    x_admin_token: str = Header(default=""),
    session: Session = Depends(get_session),
):
    """LOTTO-501: nur mit Admin-Token, nicht fuer normale Teilnehmer."""
    if x_admin_token != settings.admin_token:
        raise HTTPException(status_code=403, detail="Kein Zugriff.")
    return reset_service.setze_zurueck(session)


def _import_aus(lauf: CsvImport) -> dict:
    """Importergebnis laut CSV_FORMAT.md."""
    return {
        "id": lauf.id,
        "filename": lauf.filename,
        "outlet_id": lauf.outlet_id,
        "status": lauf.status.value,
        "started_at": lauf.started_at.isoformat() if lauf.started_at else None,
        "total_records": lauf.total_records,
        "imported_records": lauf.imported_records,
        "rejected_records": lauf.rejected_records,
        "errors": [
            {
                "line_number": fehler.line_number,
                "error_code": fehler.error_code,
                "message": fehler.message,
                "raw_data": fehler.raw_data,
            }
            for fehler in lauf.errors
        ],
    }


@router.post("/imports", tags=["imports"])
def csv_importieren(
    outlet_id: int = Form(...),
    datei: UploadFile = File(...),
    session: Session = Depends(get_session),
):
    """LOTTO-201: CSV-Datei einer Annahmestelle importieren."""
    lauf = csv_import_service.importiere(
        session, outlet_id, datei.filename or "unbenannt", datei.file.read()
    )
    return _import_aus(lauf)


@router.get("/imports", tags=["imports"])
def import_historie(session: Session = Depends(get_session)):
    """LOTTO-203: frueherer Importe."""
    return [_import_aus(lauf) for lauf in csv_import_service.historie(session)]


@router.get("/imports/{import_id}", tags=["imports"])
def import_details_api(import_id: int, session: Session = Depends(get_session)):
    """LOTTO-202: Importfehler mit Zeilennummer und Grund."""
    lauf = session.get(CsvImport, import_id)
    if lauf is None:
        raise HTTPException(status_code=404, detail="Import existiert nicht.")
    return _import_aus(lauf)
