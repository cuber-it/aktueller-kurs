"""Konfiguration ueber Environment-Variablen (siehe ARCHITECTURE.md)."""
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://lottobude:lottobude@db:5432/lottobude_tn1"
    instance_name: str = "TN"
    base_url: str = ""
    admin_token: str = "change-me"
    training_mode: bool = True
    log_level: str = "INFO"

    # --- Trainingsfehler (siehe kursleitung/BUG_KATALOG.md) ---
    # BUG-001: Spielleitungs-Endpunkte der API ohne Berechtigungspruefung.
    bug_api_admin_offen: bool = True
    # BUG-002: Tippscheine und Tipps anderer Benutzer ueber die API lesbar.
    bug_fremde_tipps_lesbar: bool = True
    # BUG-003: Ein Tippschein nimmt einen Tipp mehr an als erlaubt.
    bug_elf_tipps_erlaubt: bool = True
    # BUG-004: Gewinnbetrag bei genau vier Treffern zu niedrig.
    bug_gewinn_vier_treffer: bool = True
    # BUG-005: Abgegebener Tippschein laesst sich noch ergaenzen.
    bug_abgegebener_schein_aenderbar: bool = True
    # BUG-006: Datei ohne Kopfzeile wird als erfolgreicher Import gemeldet.
    bug_leere_datei_erfolg: bool = True
    # BUG-007: Doppelte Zahlen werden beim CSV-Import nicht erkannt.
    bug_csv_duplikate_erlaubt: bool = True
    # BUG-008: Tippschein ohne Tipps kann abgegeben werden.
    bug_leerer_schein_abgebbar: bool = True
    # BUG-009: Gewinnzahlen ausserhalb 1..49 werden akzeptiert.
    bug_gewinnzahl_ohne_bereich: bool = True
    # BUG-010: Nicht numerische Anhaengsel werden stillschweigend abgeschnitten.
    bug_zahl_abschneiden: bool = True
    # BUG-011: Falsche Kopfzeile wird akzeptiert, sofern die Spaltenzahl stimmt.
    bug_header_nur_spaltenzahl: bool = True
    # BUG-012: Bereits ausgewertete Ziehung kann erneut ausgewertet werden.
    bug_doppelte_auswertung: bool = True
    # BUG-013: Importzaehler meldet Tippscheine statt Tipps.
    bug_importzaehler_falsch: bool = True
    # BUG-014: Gesperrter Benutzer kann ueber die API abgeben.
    bug_gesperrter_darf_abgeben: bool = True

    class Config:
        env_prefix = "LOTTOBUDE_"


settings = Settings()
