"""Lottobude - Trainingsanwendung fuer QA-/Testdesign-Kurse."""
import logging

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.api.routes import router as api_router
from app.web.routes import router as web_router
from app.config import settings
from app.domain import models  # noqa: F401  - Modelle registrieren
from app.domain.models import FixtureState
from app.domain.rules import RegelVerstoss
from app.persistence.database import Base, SessionLocal, engine
from app.services.fixtures import FIXTURE_VERSION
from app.services.reset_service import setze_zurueck

logging.basicConfig(level=settings.log_level)
log = logging.getLogger("lottobude")

app = FastAPI(
    title="Lottobude",
    description=(
        "Trainingsanwendung fuer QA- und Testdesign-Uebungen. "
        "Die fachlichen Regeln stehen in BUSINESS_RULES.md."
    ),
    version="0.1.0",
)

app.mount(
    "/static",
    StaticFiles(directory=str(Path(__file__).parent / "web" / "static")),
    name="static",
)

app.include_router(api_router)
app.include_router(web_router)


@app.exception_handler(RegelVerstoss)
def regelverstoss_behandeln(request: Request, exc: RegelVerstoss) -> JSONResponse:
    """Fachliche Verstoesse werden als 400 mit maschinenlesbarem Code gemeldet."""
    return JSONResponse(
        status_code=400,
        content={"error_code": exc.error_code, "message": exc.message},
    )


@app.on_event("startup")
def schema_und_startdaten() -> None:
    Base.metadata.create_all(bind=engine)
    session = SessionLocal()
    try:
        marker = session.query(FixtureState).first()
        if marker is None or marker.version != FIXTURE_VERSION:
            # Kein oder veralteter Marker: eventuelle Reste eines
            # abgebrochenen Laufs entfernen und sauber neu aufbauen.
            # Schlaegt das fehl, darf die Anwendung nicht starten - ein
            # halber Ausgangszustand waere als Testorakel wertlos.
            ergebnis = setze_zurueck(session)
            log.info("Fixtures geladen: %s", ergebnis)
        else:
            log.info("Fixtures bereits vollstaendig (Version %s)", marker.version)
    finally:
        session.close()
    log.info("Instanz %s bereit", settings.instance_name)


@app.get("/health", tags=["system"])
def health() -> dict:
    return {"status": "ok", "instance": settings.instance_name}
