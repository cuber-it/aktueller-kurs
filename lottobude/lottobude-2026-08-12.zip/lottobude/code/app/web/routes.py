"""Weboberflaeche. Nutzt dieselben Services wie die REST-API (BR-CONS-001)."""
from datetime import date
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.config import settings
from app.domain.enums import DrawStatus, TicketStatus
from app.domain.models import CsvImport, Outlet, Ticket, User
from app.persistence.database import get_session
from app.domain.rules import RegelVerstoss
from app.services import (
    auth_service, csv_import_service, draw_service, evaluation_service,
    reset_service, ticket_service,
)

BASIS = Path(__file__).parent
templates = Jinja2Templates(directory=str(BASIS / "templates"))

router = APIRouter()

COOKIE_BENUTZER = "lottobude_user"


def aktueller_benutzer(request: Request, session: Session) -> User | None:
    """Trainingsumgebung ohne Passwoerter: der gewaehlte Benutzer steht im Cookie."""
    wert = request.cookies.get(COOKIE_BENUTZER)
    if not wert:
        return None
    try:
        return session.get(User, int(wert))
    except (TypeError, ValueError):
        return None


def rahmen(request: Request, session: Session, **werte) -> dict:
    """Gemeinsame Template-Variablen."""
    return {
        "request": request,
        "benutzer": aktueller_benutzer(request, session),
        "instanz": settings.instance_name,
        "fehler": None,
        "hinweis": None,
        **werte,
    }


@router.get("/", response_class=HTMLResponse)
def startseite(request: Request, session: Session = Depends(get_session)):
    ziehungen = draw_service.liste_ziehungen(session)
    offen = next((z for z in ziehungen if z.status is DrawStatus.GEPLANT), None)
    return templates.TemplateResponse(
        "start.html",
        rahmen(request, session, ziehungen=ziehungen, offene_ziehung=offen),
    )


@router.get("/login", response_class=HTMLResponse)
def login_maske(request: Request, session: Session = Depends(get_session)):
    return templates.TemplateResponse("login.html", rahmen(request, session))


@router.post("/login", response_class=HTMLResponse)
def login(
    request: Request,
    username: str = Form(default=""),
    passwort: str = Form(default=""),
    session: Session = Depends(get_session),
):
    """Anmeldung. Fehlerfaelle bleiben auf der Maske sichtbar."""
    try:
        benutzer = auth_service.melde_an(session, username, passwort)
    except RegelVerstoss as verstoss:
        return templates.TemplateResponse(
            "login.html", rahmen(request, session, fehler=verstoss), status_code=401
        )

    antwort = RedirectResponse(url="/", status_code=303)
    antwort.set_cookie(COOKIE_BENUTZER, str(benutzer.id), httponly=True, samesite="lax")
    return antwort


@router.get("/logout")
def logout():
    antwort = RedirectResponse(url="/login", status_code=303)
    antwort.delete_cookie(COOKIE_BENUTZER)
    return antwort


@router.get("/tippschein", response_class=HTMLResponse)
def tippschein_maske(request: Request, session: Session = Depends(get_session)):
    """LOTTO-101: Entwurf anzeigen oder anlegen lassen."""
    benutzer = aktueller_benutzer(request, session)
    offen = draw_service.offene_ziehungen(session)
    ziehung = offen[0] if offen else None

    entwurf = None
    tipps = []
    if benutzer and ziehung:
        entwurf = (
            session.query(Ticket)
            .filter(
                Ticket.user_id == benutzer.id,
                Ticket.draw_id == ziehung.id,
                Ticket.status == TicketStatus.ENTWURF,
            )
            .order_by(Ticket.id.desc())
            .first()
        )
        if entwurf:
            tipps = sorted(entwurf.tips, key=lambda t: t.tip_no)

    return templates.TemplateResponse(
        "tippschein.html",
        rahmen(
            request, session,
            offene_ziehung=ziehung, entwurf=entwurf, tipps=tipps,
            fehler=request.query_params.get("fehler"),
        ),
    )


@router.post("/tippschein")
def tippschein_anlegen(request: Request, session: Session = Depends(get_session)):
    benutzer = aktueller_benutzer(request, session)
    if benutzer is None:
        return RedirectResponse(url="/benutzer", status_code=303)
    offen = draw_service.offene_ziehungen(session)
    if not offen:
        return RedirectResponse(url="/tippschein", status_code=303)
    ticket_service.erstelle_tippschein(session, benutzer.id, offen[0].id)
    return RedirectResponse(url="/tippschein", status_code=303)


@router.post("/tippschein/tipp", response_class=HTMLResponse)
def tipp_hinzufuegen(
    request: Request,
    zahl: list[int] = Form(default=[]),
    session: Session = Depends(get_session),
):
    """LOTTO-101: Tipp erfassen. Fachliche Fehler werden in der Maske gezeigt."""
    benutzer = aktueller_benutzer(request, session)
    offen = draw_service.offene_ziehungen(session)
    ziehung = offen[0] if offen else None
    entwurf = _entwurf_von(session, benutzer, ziehung)

    fehler = None
    if entwurf is not None:
        try:
            ticket_service.fuege_tipp_hinzu(session, entwurf.id, zahl)
            return RedirectResponse(url="/tippschein", status_code=303)
        except RegelVerstoss as verstoss:
            fehler = verstoss

    return templates.TemplateResponse(
        "tippschein.html",
        rahmen(
            request, session,
            offene_ziehung=ziehung, entwurf=entwurf,
            tipps=sorted(entwurf.tips, key=lambda t: t.tip_no) if entwurf else [],
            fehler=fehler,
        ),
    )


@router.post("/tippschein/abgeben", response_class=HTMLResponse)
def tippschein_abgeben(request: Request, session: Session = Depends(get_session)):
    """LOTTO-101: Abgabe - danach ist der Schein unveraenderlich."""
    benutzer = aktueller_benutzer(request, session)
    offen = draw_service.offene_ziehungen(session)
    ziehung = offen[0] if offen else None
    entwurf = _entwurf_von(session, benutzer, ziehung)

    fehler = None
    if entwurf is not None:
        try:
            ticket_service.gib_tippschein_ab(session, entwurf.id)
            return RedirectResponse(url="/meine-tipps", status_code=303)
        except RegelVerstoss as verstoss:
            fehler = verstoss

    return templates.TemplateResponse(
        "tippschein.html",
        rahmen(
            request, session,
            offene_ziehung=ziehung, entwurf=entwurf,
            tipps=sorted(entwurf.tips, key=lambda t: t.tip_no) if entwurf else [],
            fehler=fehler,
        ),
    )


def _entwurf_von(session: Session, benutzer, ziehung):
    if benutzer is None or ziehung is None:
        return None
    return (
        session.query(Ticket)
        .filter(
            Ticket.user_id == benutzer.id,
            Ticket.draw_id == ziehung.id,
            Ticket.status == TicketStatus.ENTWURF,
        )
        .order_by(Ticket.id.desc())
        .first()
    )


@router.get("/meine-tipps", response_class=HTMLResponse)
def meine_tipps(request: Request, session: Session = Depends(get_session)):
    """LOTTO-102: eigene Tippscheine ansehen."""
    benutzer = aktueller_benutzer(request, session)
    tickets = []
    if benutzer:
        tickets = ticket_service.tippscheine_von_benutzer(session, benutzer.id)
    return templates.TemplateResponse(
        "meine_tipps.html", rahmen(request, session, tickets=tickets)
    )


@router.get("/ergebnisse", response_class=HTMLResponse)
def ergebnisse(request: Request, session: Session = Depends(get_session)):
    """LOTTO-402: Spielergebnis zu einer ausgewerteten Ziehung."""
    benutzer = aktueller_benutzer(request, session)
    ziehungen = [
        z for z in draw_service.liste_ziehungen(session)
        if z.status is DrawStatus.AUSGEWERTET
    ]
    gewaehlt = request.query_params.get("draw_id")
    ziehung = None
    if ziehungen:
        ziehung = next(
            (z for z in ziehungen if str(z.id) == gewaehlt), ziehungen[0]
        )

    zeilen = []
    if benutzer and ziehung:
        zeilen = evaluation_service.ergebnisse_von_benutzer(
            session, benutzer.id, ziehung.id
        )
    return templates.TemplateResponse(
        "ergebnisse.html",
        rahmen(request, session, ziehungen=ziehungen, ziehung=ziehung, zeilen=zeilen),
    )


def _admin_oder_absage(request: Request, session: Session):
    """Liefert None, wenn der Zugriff erlaubt ist, sonst die Absage-Antwort."""
    benutzer = aktueller_benutzer(request, session)
    if benutzer is None:
        return RedirectResponse(url="/login", status_code=303)
    if not benutzer.is_admin:
        return templates.TemplateResponse(
            "verboten.html", rahmen(request, session), status_code=403
        )
    return None


def _spielleitung_seite(request, session, fehler=None, hinweis=None):
    return templates.TemplateResponse(
        "spielleitung.html",
        rahmen(
            request, session,
            ziehungen=draw_service.liste_ziehungen(session),
            geplante=draw_service.offene_ziehungen(session),
            fehler=fehler, hinweis=hinweis,
        ),
    )


@router.get("/spielleitung", response_class=HTMLResponse)
def spielleitung(request: Request, session: Session = Depends(get_session)):
    """EPIC-3/4/5: Ziehungen verwalten, auswerten, zuruecksetzen."""
    absage = _admin_oder_absage(request, session)
    if absage is not None:
        return absage
    return _spielleitung_seite(request, session)


@router.post("/spielleitung/ziehung", response_class=HTMLResponse)
def ziehung_anlegen_web(
    request: Request,
    draw_date: date = Form(...),
    session: Session = Depends(get_session),
):
    absage = _admin_oder_absage(request, session)
    if absage is not None:
        return absage
    try:
        draw_service.lege_ziehung_an(session, draw_date)
    except RegelVerstoss as verstoss:
        return _spielleitung_seite(request, session, fehler=verstoss)
    return RedirectResponse(url="/spielleitung", status_code=303)


@router.post("/spielleitung/gewinnzahlen", response_class=HTMLResponse)
def gewinnzahlen_web(
    request: Request,
    draw_id: int = Form(...),
    zahl: list[int] = Form(default=[]),
    session: Session = Depends(get_session),
):
    absage = _admin_oder_absage(request, session)
    if absage is not None:
        return absage
    try:
        draw_service.erfasse_gewinnzahlen(session, draw_id, zahl)
    except RegelVerstoss as verstoss:
        return _spielleitung_seite(request, session, fehler=verstoss)
    return RedirectResponse(url="/spielleitung", status_code=303)


@router.post("/spielleitung/auswerten", response_class=HTMLResponse)
def auswerten_web(
    request: Request,
    draw_id: int = Form(...),
    session: Session = Depends(get_session),
):
    absage = _admin_oder_absage(request, session)
    if absage is not None:
        return absage
    try:
        evaluation_service.werte_ziehung_aus(session, draw_id)
    except RegelVerstoss as verstoss:
        return _spielleitung_seite(request, session, fehler=verstoss)
    return RedirectResponse(url="/spielleitung", status_code=303)


@router.post("/spielleitung/reset", response_class=HTMLResponse)
def reset_web(
    request: Request,
    token: str = Form(default=""),
    session: Session = Depends(get_session),
):
    """LOTTO-501: nur mit Admin-Token, nicht fuer normale Teilnehmer."""
    absage = _admin_oder_absage(request, session)
    if absage is not None:
        return absage
    if token != settings.admin_token:
        return _spielleitung_seite(
            request, session,
            fehler=RegelVerstoss("FORBIDDEN", "Falscher Admin-Token."),
        )
    reset_service.setze_zurueck(session)
    return _spielleitung_seite(request, session, hinweis="Trainingsdaten zurueckgesetzt.")


@router.get("/import", response_class=HTMLResponse)
def import_maske(request: Request, session: Session = Depends(get_session)):
    """LOTTO-201/203: Upload-Maske und Importhistorie."""
    return templates.TemplateResponse(
        "import.html",
        rahmen(
            request, session,
            annahmestellen=session.query(Outlet).order_by(Outlet.id).all(),
            verlauf=csv_import_service.historie(session),
            lauf=None,
        ),
    )


@router.post("/import", response_class=HTMLResponse)
def import_durchfuehren(
    request: Request,
    outlet_id: int = Form(...),
    datei: UploadFile = File(...),
    session: Session = Depends(get_session),
):
    """LOTTO-201: Datei einlesen, Ergebnis anzeigen."""
    fehler = None
    lauf = None
    try:
        lauf = csv_import_service.importiere(
            session, outlet_id, datei.filename or "unbenannt", datei.file.read()
        )
    except RegelVerstoss as verstoss:
        fehler = verstoss

    return templates.TemplateResponse(
        "import.html",
        rahmen(
            request, session,
            annahmestellen=session.query(Outlet).order_by(Outlet.id).all(),
            verlauf=csv_import_service.historie(session),
            lauf=lauf, fehler=fehler,
        ),
    )


@router.get("/import/{import_id}", response_class=HTMLResponse)
def import_details(
    import_id: int, request: Request, session: Session = Depends(get_session)
):
    """LOTTO-202: Fehlerhafte Datensaetze mit Grund und Zeilennummer."""
    lauf = session.get(CsvImport, import_id)
    if lauf is None:
        return templates.TemplateResponse(
            "verboten.html", rahmen(request, session), status_code=404
        )
    return templates.TemplateResponse(
        "import_details.html", rahmen(request, session, lauf=lauf)
    )
