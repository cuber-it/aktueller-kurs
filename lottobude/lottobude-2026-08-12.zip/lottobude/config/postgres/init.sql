-- Je Teilnehmer eine eigene Datenbank, damit sich die Instanzen nicht stoeren.
CREATE DATABASE lottobude_tn1;
CREATE DATABASE lottobude_tn2;
CREATE DATABASE lottobude_review;
