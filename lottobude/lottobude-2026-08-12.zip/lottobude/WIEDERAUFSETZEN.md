# Lottobude - Wiederaufsetzen

Stand: 2026-08-12. Getestet auf Ubuntu 26.04 (Hetzner Cloud, 2 Kerne, 4 GB).

## Voraussetzungen

```
apt-get install -y docker.io docker-compose-v2 certbot
```

Ein DNS-Name muss auf den Server zeigen. Im Auslieferungsstand ist das
`playground.uc-it.de`; bei einem anderen Namen sind anzupassen:

- `config/nginx/lottobude.conf` (`server_name` und die Zertifikatspfade)
- `docker-compose.yml` (`LOTTOBUDE_BASE_URL` je Instanz)
- `config/nginx/landing/index.html`, falls die Landing-Seite wieder genutzt wird

## Zertifikat

Vor dem ersten Start holen, solange Port 80 frei ist:

```
certbot certonly --standalone --non-interactive --agree-tos \
        --email <adresse> -d <dnsname>
mkdir -p /var/www/certbot
```

## Geheimnisse

`.env` enthaelt das Datenbankkennwort und den Admin-Token. Fuer einen neuen
Kurs neu erzeugen:

```
printf 'POSTGRES_PASSWORD=%s\nLOTTOBUDE_ADMIN_TOKEN=%s\n' \
  "$(head -c 24 /dev/urandom | base64 | tr -d '/+=' | head -c 24)" \
  "$(head -c 18 /dev/urandom | base64 | tr -d '/+=' | head -c 18)" > .env
chmod 600 .env
```

## Starten

```
docker compose up -d --build
```

Die Instanzen legen ihr Schema selbst an und laden die Fixtures. Danach:

- TN 1   https://<dnsname>:10000
- TN 2   https://<dnsname>:10001
- Review https://<dnsname>

## Stolpersteine

- **Nach Aenderungen an der nginx-Konfiguration `nginx -s reload`**, nicht
  `docker compose restart` - der Restart liest die Datei nicht neu ein.
- Werden die Anwendungscontainer neu erstellt, behaelt nginx ohne den
  `resolver`-Eintrag alte Container-Adressen und liefert 502. Der Eintrag
  ist in `lottobude.conf` bereits gesetzt.
- Schema-Aenderungen an den Modellen legt `create_all` in bestehenden
  Tabellen **nicht** nach. Dann Volume verwerfen:
  `docker compose down && docker volume rm lottobude_pgdata`

## Trainingsfehler

14 Bugs, einzeln ueber Umgebungsvariablen abschaltbar. Namen, Sollverhalten
und Reproduktion stehen in `kursleitung/BUG_KATALOG.md`. Alle sind im
Auslieferungsstand aktiv.

Zum Abschalten die jeweilige Variable im betreffenden Dienst in
`docker-compose.yml` auf `false` setzen, z.B.:

```
LOTTOBUDE_BUG_ELF_TIPPS_ERLAUBT: "false"
```

## Reset der Trainingsdaten

```
curl -X POST https://<dnsname>/api/admin/reset -H "X-Admin-Token: <token>"
```

Stellt Benutzer, Annahmestellen, Ziehungen und Tippscheine wieder her und
setzt die Datenbanksequenzen zurueck, damit die IDs reproduzierbar bleiben.
